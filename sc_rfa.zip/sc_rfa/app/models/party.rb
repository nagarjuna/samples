#
# Table Schema
# ------------
# id            - int(11)      - default NULL
# host_name     - varchar(255) - default NULL
# host_email    - varchar(255) - default NULL
# numgsts       - int(11)      - default NULL
# guest_names   - text         - default NULL
# venue         - varchar(255) - default NULL
# location      - varchar(255) - default NULL
# theme         - varchar(255) - default NULL
# starting_at   - datetime     - default NULL
# ending_at     - datetime     - default NULL
# description   - text         - default NULL
#

class Party < ApplicationRecord

	validates :host_name, :host_email, :venue, :location, :theme, presence: true, length: { maximum: 255 }

	validates :starting_at,  :date => { :after => Proc.new { Date.today }, message: 'must be after today'}
  	validates :ending_at, :date => { :after => Proc.new { |p| p.starting_at }, message: 'must be after party starting time' }, :if => "starting_at.present? && starting_at.present?"

  	validate :is_guest_names_eq_numgsts?

  	# before_save :change_guest_names

  	def is_guest_names_eq_numgsts?
  		errors.add(:guest_names,"Missing guest name") if guest_names.split(',').size != numgsts
  	end

  	def change_guest_names
	    # clean "Harry S. Truman" guest name to "Harry S._Truman"
	    # clean "Roger      Rabbit" guest name to "Roger Rabbit"
	    gnames = []
	    guest_names.split(',').each do |g|
	      g.squeeze!
	      names=g.split(' ')
	      gnames << "#{names[0]} #{names[1..-1].join('_')}"
	    end
	    guest_names = gnames
	    save!
	end

end
