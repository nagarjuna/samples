class PartiesController < ApplicationController

	def index

		sort = (params[:sort].present? && Party.column_names.include?(params[:sort].downcase)) ? params[:sort].downcase : "starting_at"
		order = (params[:by].present? && ["desc", "asc"].include?(params[:by].downcase)) ? params[:by].upcase : "DESC"
    @parties = Party.order(sort+" "+order).paginate(page: params[:page], per_page: params[:per_page] || 30)
  end

  def new
    @party = Party.new(:numgsts => 0)
  end

  def create
    @party = Party.new(party_params)
    if @party.save
      redirect_to parties_path, :notice => "Party created successfully."
    else
      flash.now[:error]="Party was incorrect."
      render :new
    end
	end

	private
	def party_params
    params.require(:party).permit(:host_name, :host_email, :numgsts, :guest_names, :venue, :location, :theme, :starting_at, :ending_at, :description)
  end
end
