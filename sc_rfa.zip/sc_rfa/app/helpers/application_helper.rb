module ApplicationHelper

	def display_form_errors(obj, field)
		content_tag( :div, obj.errors[field].to_sentence, :class=>'error_message') 
	end
end
