class CreateParties < ActiveRecord::Migration[5.0]
  def change
    create_table :parties do |t|
    	t.string :host_name
    	t.string :host_email
    	t.integer :numgsts
    	t.text :guest_names
    	t.string :venue
    	t.string :location
    	t.string :theme
    	t.datetime :starting_at
    	t.datetime :ending_at
    	t.text :description
    	
      	t.timestamps
    end
  end
end
